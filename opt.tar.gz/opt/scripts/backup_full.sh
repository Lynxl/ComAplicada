#!/bin/bash

#Menú de Ayuda
function menu_ayuda {
	echo "Sintaxis: $0 -o (Directorio de Origen) -d (Directorio de Destino)"
	echo "Parámetros:"
	echo "-help	Muestra este menú de Ayuda"
	echo "-o	Directorio a Backupear (Origen)"
	echo "-d	Directorio de Almacenamiento (Destino)"
	exit 0
}

if [[ "$1" == "-help" ]]; then
	menu_ayuda
fi

#Validación de Argumentos
while getopts "o:d:" opt; do
	case ${opt} in
		o) ORIGEN=$OPTARG ;;
		d) DESTINO=$OPTARG ;;
		*) echo "Opción Inválida: (-$OPTARG)"; menu_ayuda ;;
	esac
done

#Validación de Parámetros
if [[ -z "$ORIGEN" ]]; then
	echo "Error de Parámetros!"
	echo "Debe especificar el Directorio de Origen (-o)"
	menu_ayuda
fi

if [[ -z "$DESTINO" ]]; then
	echo "Error de Parámetros!"
	echo "Debe especificar el Directorio de Destino (-d)"
	menu_ayuda
fi

#Validar Existencia Directorios
if [[ ! -d "$ORIGEN" ]]; then
	echo "Error! El directorio '$ORIGEN' no existe."
	menu_ayuda
fi

if [[ ! -d "$DESTINO" ]]; then
	echo "Error! El directorio '$DESTINO' no existe."
	menu_ayuda
fi

#Generador de Backup
FECHA=$(date +%Y%m%d)
NOMBRE_BASE=$(basename "$ORIGEN")
NOMBRE_BACKUP="$DESTINO/${NOMBRE_BASE}_bkp_${FECHA}.tar.gz"

tar -czf "$NOMBRE_BACKUP" "$ORIGEN"

#Verificación Backup
if [[ $? -eq 0 ]]; then
	echo "Backup Exitoso! $NOMBRE_BACKUP"
else
    echo "Error! No se pudo crear el Backup..."
    exit 1
fi